<?php
require_once '../config/database.php';

$data = json_decode(file_get_contents("php://input"), true);
$id = $data['id'];
$read_status = $data['read_status'];

$stmt = $pdo->prepare("UPDATE duty_logs SET read_status = ? WHERE id = ?");
$stmt->execute([$read_status, $id]);

echo json_encode(["success" => true]);
?>