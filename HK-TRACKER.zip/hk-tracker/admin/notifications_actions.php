<?php
session_start();
require_once '../config/database.php';

header("Content-Type: application/json");

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["success" => false, "message" => "Invalid request"]);
    exit();
}

// Get the JSON input
$data = json_decode(file_get_contents("php://input"), true);

// Validate action
if (!isset($data['action'])) {
    echo json_encode(["success" => false, "message" => "Action not provided"]);
    exit();
}

$action = $data['action'];

if ($action === "mark_read" && isset($data['student_id'])) {
    // Mark a single notification as read
    $stmt = $pdo->prepare("UPDATE notifications SET status = 'Read' WHERE student_id = ?");
    $stmt->execute([$data['student_id']]);
    echo json_encode(["success" => true, "message" => "Notification marked as read"]);
} 
elseif ($action === "mark_all_read") {
    // Mark all notifications as read
    $stmt = $pdo->prepare("UPDATE notifications SET status = 'Read' WHERE status = 'Pending'");
    $stmt->execute();
    echo json_encode(["success" => true, "message" => "All notifications marked as read"]);
} 
elseif ($action === "clear_all") {
    // Clear all read notifications
    $stmt = $pdo->prepare("DELETE FROM notifications WHERE status = 'Read'");
    $stmt->execute();
    echo json_encode(["success" => true, "message" => "All read notifications cleared"]);
} 
else {
    echo json_encode(["success" => false, "message" => "Invalid action"]);
}
?>