<?php
session_start();
require_once '../config/database.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit();
}

$admin_id = $_SESSION["admin_id"]; // Fix: Use admin_id

// Fetch Profile Photo for Admin
$sql = "SELECT profile_photo FROM admin WHERE id = ?";
$stmt = $pdo->prepare($sql); // Fix: Use PDO instead of $conn
$stmt->execute([$admin_id]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);
$profilePhoto = !empty($row["profile_photo"]) ? "../uploads/" . $row["profile_photo"] : "../assets/image/default.jpg";

// Fetch Student Count
$stmt = $pdo->prepare("SELECT COUNT(*) AS total_students FROM students");
$stmt->execute();
$total_students = $stmt->fetch(PDO::FETCH_ASSOC)['total_students'];

// Fetch Pending Duty Logs
$stmt = $pdo->prepare("SELECT COUNT(*) AS pending_logs FROM duty_logs WHERE status = 'Pending'");
$stmt->execute();
$pending_logs = $stmt->fetch(PDO::FETCH_ASSOC)['pending_logs'];

// Fetch Admin Details
$stmt = $pdo->prepare("SELECT * FROM admin WHERE id = ?");
$stmt->execute([$admin_id]);
$admin_data = $stmt->fetch(PDO::FETCH_ASSOC);

// Ensure the admin data exists before assigning variables
$admin_name = $admin_data['name'] ?? "Not Set";
$admin_email = $admin_data['email'] ?? "Email Not Set";
$admin_role = $admin_data['role'] ?? "Not Assigned"; // Fetch Role
$admin_password = $admin_data['password'] ?? ""; // Fetch Password (Hashed)

// Assign username
$admin_username = $admin_name; // Assuming admin's username is their name

// First name only
$first_name = explode(' ', $admin_name)[0]; // Get only the first word of the name

// Admin username
$admin_username = $admin_name;

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Profile</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="icon" href="../assets/image/icontitle.png">
    <link rel="stylesheet" href="../assets/admin_profile.css">
    <script src="https://kit.fontawesome.com/YOUR_KIT_CODE.js" crossorigin="anonymous"></script>
</head>

<body>
    <div class="dashboard-container">
        <?php include '../includes/sidebar.php' ?>
        <main class="main-content">
            <div class="content">
                <!-- profile Section -->
                <div class="profile-container">
                    <div class="profile-card">
                        <img src="<?php echo $profilePhoto; ?>" alt="Profile Picture" class="profile-pic">
                        <div class="profile-info">
                            <h2 class="full-name"><?php echo $admin_name; ?></h2>
                            <p class="role">
                                <i class="fa-solid fa-shield-halved"></i>
                                Admin
                            </p>
                            <div class="profile-stats">
                                <div class="stat-item">
                                    <span class="stat-value"><?php echo $total_students; ?></span>
                                    <span class="stat-label">Total Students</span>
                                </div>
                                <div class="stat-item">
                                    <span class="stat-value"><?php echo $pending_logs; ?></span>
                                    <span class="stat-label">Pending Approval</span>
                                </div>
                                <div class="stat-item">
                                    <span class="stat-value" id="notificationCount"> Unread Messages</span>
                                    <span class="stat-label">Notifications</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- account Details Section -->
                <div class="account-section">
                    <h2 class="section-title">Account Details</h2>
                    <div class="account-container">
                        <div class="account-card">
                            <div class="account-header">
                                <i class="fa-regular fa-user"></i>
                                <h3>Personal Information</h3>
                            </div>
                            <div class="account-details">
                                <div class="detail-item">
                                    <span class="detail-label">Account Status</span>
                                    <span class="status-active">Active</span>
                                </div>
                                <div class="detail-item">
                                    <span class="detail-label">Username:</span>
                                    <span class="detail-value"><?php echo $admin_name; ?></span>
                                </div>
                                <div class="detail-item">
                                    <span class="detail-label">Email:</span>
                                    <span class="detail-value"><?php echo $admin_email; ?></span>
                                </div>
                                <!-- Add Role and Password Fields -->
                                <div class="detail-item">
                                    <span class="detail-label">Role:</span>
                                    <span class="detail-value"
                                        id="roleDisplay"><?php echo htmlspecialchars($admin_data['role']); ?></span>
                                </div>

                                <div class="detail-item">
                                    <span class="detail-label">Password:</span>
                                    <span class="detail-value">********</span> <!-- Hide actual password -->
                                </div>

                            </div>
                            <div class="edit-button">
                                <button><i class="fa-solid fa-pen-to-square"></i> Edit Information</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <!-- New Profile Modal -->
    <div class="profile-modal-overlay">
        <div class="profile-modal">
            <div class="profile-modal-header">
                <div class="profile-photo-container">
                    <img id="profile-img" src="<?php echo $profilePhoto; ?>" alt="Profile Picture"
                        class="profile-photo">
                    <input type="file" id="profile-photo-input" style="display: none;">
                    <div class="photo-edit-button" onclick="document.getElementById('profile-photo-input').click();">
                        <i class="fa-solid fa-camera"></i>
                    </div>
                </div>
                <div class="profile-header-info">
                    <h2><?php echo $admin_name; ?></h2>
                    <p><?php echo $admin_email; ?></p>
                </div>
            </div>
            <hr class="divider">
            <form class="profile-form" id="profileForm">
                <div class="form-group full-width">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username"
                        value="<?php echo htmlspecialchars($admin_username); ?>">
                </div>
                <hr class="divider">
                <div class="form-group full-width">
                    <label for="email">Email address</label>
                    <div class="email-input-container">
                        <i class="fa-solid fa-envelope email-icon"></i>
                        <input type="email" id="email" name="email"
                            value="<?php echo htmlspecialchars($admin_email); ?>" class="email-input">
                    </div>
                </div>
                <hr class="divider">
                <div class="form-group full-width">
                    <label for="role">Role</label>
                    <select id="role" name="role">
                        <option value="Department Admin"
                            <?php echo ($admin_role == "Department Admin") ? "selected" : ""; ?>>Department Admin
                        </option>
                    </select>
                </div>
                <hr class="divider">
                <div class="form-group full-width">
                    <label for="password">New Password</label>
                    <input type="password" id="password" name="password" placeholder="Enter new password">
                </div>
                <class="divider">
                    <div class="form-actions">
                        <button type="button" class="cancel-button">Cancel</button>
                        <button type="submit" class="save-button">Save changes</button>
                    </div>

            </form>
        </div>
    </div>

    <script>
    // Modal Handling
    const editButton = document.querySelector('.edit-button'); // Ensure there's an element with this class
    const modalOverlay = document.querySelector('.profile-modal-overlay');
    const cancelButton = document.querySelector('.cancel-button');

    if (editButton) {
        editButton.addEventListener('click', () => {
            modalOverlay.style.display = 'flex';
        });
    }

    // Hide modal
    [cancelButton, modalOverlay].forEach(element => {
        element.addEventListener('click', (e) => {
            if (e.target === element || element.classList.contains('cancel-button')) {
                modalOverlay.style.display = 'none';
            }
        });
    });

    // Prevent modal close when clicking inside
    document.getElementById('profileForm').addEventListener('submit', (e) => {
        e.preventDefault();

        const formData = new FormData();
        formData.append("username", document.getElementById("username").value);
        formData.append("email", document.getElementById("email").value);
        formData.append("role", document.getElementById("role").value);

        const password = document.getElementById("password").value;
        if (password.trim() !== "") {
            formData.append("password", password);
        }

        fetch("update_profile.php", {
                method: "POST",
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === "success") {
                    document.querySelector('.full-name').textContent = document.getElementById("username")
                        .value;
                    document.querySelectorAll('.detail-value')[0].textContent = document.getElementById(
                        "username").value;
                    document.querySelectorAll('.detail-value')[1].textContent = document.getElementById(
                        "email").value;
                    alert("Profile updated successfully!");
                    modalOverlay.style.display = 'none';
                } else {
                    alert(data.message);
                }
            })
            .catch(error => console.error("Error:", error));
    });

    // Simplify to a single event handler for photo upload
    document.getElementById('profile-photo-input').addEventListener('change', function() {
        if (this.files && this.files[0]) {
            console.log("File selected:", this.files[0].name);

            const formData = new FormData();
            formData.append("profile_photo", this.files[0]);

            // Log the entire FormData contents
            for (let pair of formData.entries()) {
                console.log(pair[0] + ': ' + pair[1]);
            }

            fetch("upload_profile.php", {
                    method: "POST",
                    body: formData
                })
                .then(response => {
                    console.log("Response status:", response.status);
                    return response.text(); // Get raw text first
                })
                .then(text => {
                    console.log("Raw response:", text);
                    try {
                        return JSON.parse(text); // Try to parse as JSON
                    } catch (e) {
                        console.error("JSON parse error:", e);
                        throw new Error("Invalid JSON response: " + text);
                    }
                })
                .then(data => {
                    console.log("Parsed data:", data);
                    if (data.status === "success") {
                        // Update images
                        const allProfileImages = document.querySelectorAll('.profile-pic, .profile-photo');
                        allProfileImages.forEach(img => {
                            img.src = data.filePath;
                        });
                        console.log("Profile updated with path:", data.filePath);
                    } else {
                        alert("Upload failed: " + data.message);
                    }
                })
                .catch(error => {
                    console.error("Fetch error:", error);
                    alert("An error occurred during upload. Check console for details.");
                });
        }
    });
    </script>
</body>

</html>