<?php
session_start();
require_once '../config/database.php';

// Ensure the admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit();
}

// Check if student_id is passed in the URL
if (!isset($_GET['student_id']) || empty($_GET['student_id'])) {
    die("Invalid request. Student ID is missing.");
}

$student_number = $_GET['student_id']; // This is students.student_id

// Fetch student info using student_number (students.student_id) to get the internal ID
$stmt = $pdo->prepare("
    SELECT s.*, 
           COALESCE(
               (SELECT SUM(total_hours) 
                FROM duty_logs 
                WHERE student_id = s.id AND status = 'Approved'), 
               0
           ) AS total_hours
    FROM students s
    WHERE s.student_id = ?
");
$stmt->execute([$student_number]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);

// If student not found, show an error
if (!$student) {
    die("Student not found with student_id: " . htmlspecialchars($student_number));
}

$student_id = $student['id']; // Use the internal ID for duty_logs

// Determine required duty hours based on scholarship type
$required_hours = 90; // Default required hours
if ($student['scholarship_type'] == "HK 25") {
    $required_hours = 50;
} elseif ($student['scholarship_type'] == "HK 50") {
    $required_hours = 90;
} elseif ($student['scholarship_type'] == "HK 75") {
    $required_hours = 120;
}

// Convert decimal total_hours into hours and minutes
$total_hours_decimal = $student['total_hours'];
$hours = floor($total_hours_decimal);
$minutes = round(($total_hours_decimal - $hours) * 60);
$total_hours_display = "$hours hr" . ($minutes > 0 ? " $minutes m" : "");

// Fetch duty logs for the student using students.id
$duty_stmt = $pdo->prepare("
    SELECT 
        id,
        student_id,
        time_in,
        time_out,
        total_hours,
        COALESCE(duty_date, DATE(time_in)) AS duty_date,
        status
    FROM duty_logs 
    WHERE student_id = ?
    ORDER BY time_in DESC
");
$duty_stmt->execute([$student_id]);
$duty_logs = $duty_stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Student Logs</title>
    <link rel="icon" href="../assets/image/icontitle.png" />
    <link rel="stylesheet" href="../assets/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="../assets/search_filter.js"></script>
    <style>
    .dropdown {
        position: relative;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        vertical-align: middle;
        display: inline-block;
    }

    .dropdown-content {
        display: none;
        position: absolute;
        background-color: white;
        box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.2);
        min-width: 140px;
        z-index: 1;
        right: 0;
        border-radius: 5px;
        padding: 5px 0;
    }

    .dropdown-content a {
        color: black;
        padding: 8px 12px;
        text-decoration: none;
        display: block;
        cursor: pointer;
    }

    .dropdown-content a:hover {
        background-color: #f1f1f1;
    }

    .dropdown:hover .dropdown-content {
        display: block;
    }

    .reset-duty-logs-btn {
        text-align: center;
        margin-top: 10px;
        background-color: #dc3545;
        color: white;
        border: none;
        padding: 8px 15px;
        font-size: 14px;
        cursor: pointer;
        border-radius: 5px;
    }

    .reset-duty-logs-btn:hover {
        background-color: #c82333;
    }
    </style>
</head>

<body>
    <div class="dashboard-container">
        <?php include '../includes/sidebar.php'; ?>
        <main class="main-content">
            <header class="header-container">
                <div class="header-left">
                    <h2>
                        <i class="fa-solid fa-arrow-left" onclick="window.location.href='total_students.php'"
                            style="cursor: pointer;"></i>
                        <i class="fa-regular fa-clock"></i>
                        Student View Logs
                    </h2>
                </div>
                <div class="header-right">
                    <div class="search-sort-container">
                        <div class="search-container">
                            <i class="fas fa-search"></i>
                            <input type="text" id="searchInput" placeholder="Search...">
                        </div>
                        <div class="dropdown">
                            <img src="../assets/image/sort-icon.jpg" alt="Sort" onclick="toggleDropdown()">
                            <div class="dropdown-content" id="dropdown">
                                <select id="sortSelect">
                                    <option value="" disabled selected>--Filter--</option>
                                    <option value="id">ID</option>
                                    <option value="student_id">Student ID</option>
                                    <option value="name">Name</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            <section class="table-container">
                <table id="studentsTable">
                    <thead>
                        <tr>
                            <th>Duty Date</th>
                            <th>Time In</th>
                            <th>Time Out</th>
                            <th>Hours Worked</th>
                            <th>Status
                                <div class="dropdown">
                                    <img src="../assets/image/drop-status.png" alt="Filter Status"
                                        style="width: 18px; height: 18px; cursor: pointer; margin-right: 5px;">
                                    <div class="dropdown-content">
                                        <a onclick="filterByStatus('All')">Show All</a>
                                        <a onclick="filterByStatus('Approved')">Approved</a>
                                        <a onclick="filterByStatus('Pending')">Pending</a>
                                        <a onclick="filterByStatus('Rejected')">Rejected</a>
                                    </div>
                                </div>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($duty_logs)): ?>
                        <?php foreach ($duty_logs as $log): ?>
                        <tr class="log-row" data-status="<?php echo htmlspecialchars($log['status']); ?>">
                            <td><?php echo htmlspecialchars($log['duty_date'] ?? 'N/A'); ?></td>
                            <td><?php echo $log['time_in'] && strtotime($log['time_in']) !== false ? date('h:i A', strtotime($log['time_in'])) : 'N/A'; ?></td>
                            <td><?php echo $log['time_out'] && strtotime($log['time_out']) !== false ? date('h:i A', strtotime($log['time_out'])) : 'N/A'; ?></td>
                            <td>
                                <?php 
                                try {
                                    if ($log['status'] === 'Rejected' || !$log['time_out']) {
                                        echo "0 hrs";
                                    } else {
                                        $total_hours = floatval($log['total_hours'] ?? 0);
                                        $hours = floor($total_hours);
                                        $minutes = round(($total_hours - $hours) * 60);
                                        if ($hours > 0) {
                                            echo "{$hours} hr" . ($hours > 1 ? "s" : "") . ($minutes > 0 ? " {$minutes} min" : "");
                                        } else {
                                            echo $minutes > 0 ? "{$minutes} min" : "0 min";
                                        }
                                    }
                                } catch (Exception $e) {
                                    echo "Error: " . htmlspecialchars($e->getMessage());
                                }
                                ?>
                            </td>
                            <td class="<?php echo htmlspecialchars($log['status'] == 'Pending' ? 'status-pending' : ($log['status'] == 'Approved' ? 'status-approved' : 'status-rejected')); ?>">
                                <?php 
                                switch ($log['status']) {
                                    case 'Pending':
                                        echo '<i class="fa-solid fa-clock"></i> Pending';
                                        break;
                                    case 'Approved':
                                        echo '<i class="fa-solid fa-check-circle"></i> Approved';
                                        break;
                                    case 'Rejected':
                                        echo '<i class="fa-solid fa-times-circle"></i> Rejected';
                                        break;
                                    default:
                                        echo htmlspecialchars($log['status'] ?? 'Unknown');
                                }
                                ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php else: ?>
                        <tr>
                            <td colspan="5">No duty logs found.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </section>
            <p class="total-hours-container-text"><strong>Total Hours Worked: <span><?php echo "$total_hours_display / $required_hours hrs"; ?></span></strong></p>
            <form id="resetLogsForm">
                <input type="hidden" id="studentId" value="<?php echo htmlspecialchars($student_number); ?>">
                <button type="button" class="reset-duty-logs-btn" id="resetLogsBtn">Reset Logs</button>
            </form>
        </main>
    </div>

    <script>
    function filterByStatus(status) {
        let rows = document.querySelectorAll(".log-row");
        rows.forEach(row => {
            let rowStatus = row.getAttribute("data-status");
            row.style.display = (status === "All" || rowStatus === status) ? "" : "none";
        });
    }

    document.getElementById("resetLogsBtn").addEventListener("click", function() {
        let studentId = document.getElementById("studentId").value;
        if (confirm("Are you sure you want to reset all logs for this student?")) {
            fetch("reset_logs.php", {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: "student_id=" + encodeURIComponent(studentId)
            })
            .then(response => response.json())
            .then(data => {
                alert(data.message);
                if (data.status === "success") {
                    location.reload();
                }
            })
            .catch(error => console.error("Error:", error));
        }
    });
    </script>
</body>

</html>