<!-- <?php
// Create this as reset_total_hours.php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['admin_id'])) {
    die("Unauthorized access");
}

try {
    // Start transaction for data integrity
    $pdo->beginTransaction();
    
    // Step 1: First reset all total_hours to 0
    $resetStmt = $pdo->prepare("UPDATE students SET total_hours = 0");
    $resetStmt->execute();
    
    // Step 2: Calculate correct total hours from approved duty logs
    $calculateStmt = $pdo->prepare("
        SELECT student_id, SUM(hours_worked) as total_hours
        FROM duty_logs
        WHERE status = 'Approved'
        GROUP BY student_id
    ");
    $calculateStmt->execute();
    $studentHours = $calculateStmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Step 3: Update each student with their correct total hours
    $updateStmt = $pdo->prepare("
        UPDATE students
        SET total_hours = ?
        WHERE student_id = ?
    ");
    
    $updatedCount = 0;
    foreach ($studentHours as $student) {
        $updateStmt->execute([$student['total_hours'], $student['student_id']]);
        $updatedCount++;
    }
    
    // Commit all changes
    $pdo->commit();
    
    echo "<h2>Database Update Complete</h2>";
    echo "<p>Reset all student hours to 0</p>";
    echo "<p>Updated $updatedCount students with correct total hours</p>";
    echo "<p><a href='student_profiles.php'>Return to Student Profiles</a></p>";
    
} catch (Exception $e) {
    // Roll back transaction on error
    $pdo->rollBack();
    echo "<h2>Error</h2>";
    echo "<p>" . $e->getMessage() . "</p>";
}
?> -->