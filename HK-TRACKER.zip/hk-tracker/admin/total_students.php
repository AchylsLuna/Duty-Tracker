<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit();
}

// Fetch students with total hours
$stmt = $pdo->query("
    SELECT s.id, s.student_id, s.name, s.email, s.scholarship_type,
           COALESCE((SELECT SUM(total_hours) 
                     FROM duty_logs 
                     WHERE student_id = s.student_id 
                     AND status = 'Approved'), 0) AS total_hours
    FROM students s
");
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Update hk_duty_status in the database
foreach ($students as &$student) {
    $total_hours = (float) $student['total_hours'];
    $required_hours = 90;  // Default
    if ($student['scholarship_type'] == 'HK 25') {
        $required_hours = 50;
    } elseif ($student['scholarship_type'] == 'HK 50') {
        $required_hours = 90;
    } elseif ($student['scholarship_type'] == 'HK 75') {
        $required_hours = 120;
    }
    $duty_status = ($total_hours >= $required_hours) ? 'Completed' : 'In Progress';
    $student['duty_status'] = $duty_status;  // Add to array for display
    
    $update_stmt = $pdo->prepare("UPDATE students SET hk_duty_status = ? WHERE student_id = ?");
    $update_stmt->execute([$duty_status, $student['student_id']]);
}
unset($student);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Total Students</title>
    <link rel="icon" href="../assets/image/icontitle.png" />
    <link rel="stylesheet" href="../assets/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="../assets/search_filter.js"></script>
    <script src="../assets/remove_students.js"></script>
</head>

<body>
    <div class="dashboard-container">
        <?php include '../includes/sidebar.php'?>

        <main class="main-content">
            <header class="header-container">
                <div class="header-left">
                    <h2>
                        <i class="fa-solid fa-arrow-left" onclick="window.location.href='dashboard.php'"
                            style="cursor: pointer;"></i>
                    </h2>
                    <h2><i class="fas fa-users"></i> Total Students</h2>
                </div>

                <div class="header-right">
                    <div class="search-sort-container">
                        <div class="search-container">
                            <i class="fas fa-search"></i>
                            <input type="text" id="searchInput" placeholder="Search...">
                        </div>

                        <div class="dropdown">
                            <img src="../assets/image/sort-icon.jpg" alt="Sort" onclick="toggleDropdown()">
                            <div class="dropdown-content" id="dropdown">
                                <select id="sortSelect">
                                    <option value="" disabled selected>--Filter--</option>
                                    <option value="id">ID</option>
                                    <option value="student_id">Student ID</option>
                                    <option value="name">Name</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            <section class="table-container">
                <div class="table-actions">
                    <button class="delete-btn" id="deleteSelected">
                        <i class="fas fa-user-times"></i> Remove User
                    </button>
                    <a href="add_student.php" class="add-student-btn">
                        <i class="fa fa-user-plus"></i> Add Student
                    </a>
                </div>

                <div class="table-content">
                    <table id="studentsTable">
                        <thead>
                            <tr>
                                <th><input type="checkbox" id="selectAll"></th>
                                <th class="sortable" data-column="id">ID</th>
                                <th class="sortable" data-column="student_id">Student ID</th>
                                <th class="sortable" data-column="name">Name</th>
                                <th class="sortable" data-column="email">Email</th>
                                <th class="sortable" data-column="duty_status">Duty Status</th>
                                <th class="sortable" data-column="view_logs">View Logs</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($students as $student): ?>
                            <tr>
                                <td><input type="checkbox" class="selectItem"
                                        value="<?php echo htmlspecialchars($student['id']); ?>"></td>
                                <td><?php echo htmlspecialchars($student['id']); ?></td>
                                <td><?php echo htmlspecialchars($student['student_id']); ?></td>
                                <td><?php echo htmlspecialchars($student['name']); ?></td>
                                <td><?php echo htmlspecialchars($student['email']); ?></td>

                                <td>
                                    <?php
                                    // Access the pre-calculated $total_hours from the fetched student data
                                    $total_hours = (float) $student['total_hours']; // Ensure it's a number

                                    // Default required hours
                                    $required_hours = 90;
                                    if ($student['scholarship_type'] == "HK 25") {
                                        $required_hours = 50;
                                    } elseif ($student['scholarship_type'] == "HK 50") {
                                        $required_hours = 90;
                                    } elseif ($student['scholarship_type'] == "HK 75") {
                                        $required_hours = 120;
                                    }

                                    // Determine duty status based on the total hours and required hours
                                    $duty_status = ($total_hours >= $required_hours) ? "Completed" : "In Progress";

                                    // Set color and display based on duty status
                                    $color = ($duty_status === "Completed") ? "green" : (($duty_status === "In Progress") ? "orange" : "gray");
                                    ?>
                                    <span style="color: <?php echo $color; ?>; font-weight: bold;">
                                        <?php echo $duty_status; ?>
                                    </span>
                                </td>

                                <td>
                                    <a href="viewstudent_log.php?student_id=<?php echo htmlspecialchars($student['student_id']); ?>"
                                        class="view-logs-btn">
                                        <svg class="eye-icon" xmlns="http://www.w3.org/2000/svg" width="20" height="20"
                                            viewBox="0 0 16 16" fill="blue">
                                            <path
                                                d="M8 2C4 2 1 6 1 6s3 4 7 4 7-4 7-4-3-4-7-4Zm0 6.5A2.5 2.5 0 1 1 8 3a2.5 2.5 0 0 1 0 5.5Z" />
                                        </svg>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </main>
    </div>
</body>

</html>