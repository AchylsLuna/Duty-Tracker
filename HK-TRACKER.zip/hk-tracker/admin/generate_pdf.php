<?php
require_once('../vendor/tecnickcom/tcpdf/tcpdf.php');
require_once '../config/database.php';

// Start session and authenticate
session_start();
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit();
}

$admin_id = $_SESSION['admin_id'];

// Validate and sanitize student ID
if (!isset($_GET['student_id']) || empty($_GET['student_id'])) {
    die("Error: Student ID not provided.");
}

$student_id = filter_var($_GET['student_id'], FILTER_SANITIZE_STRING);
$status_filter = isset($_GET['status']) ? filter_var($_GET['status'], FILTER_SANITIZE_STRING) : 'all';

try {
    // Fetch student details using the VARCHAR student_id to get the INT id
    $stmt = $pdo->prepare("
        SELECT s.* 
        FROM students s
        WHERE s.student_id = ?
    ");
    $stmt->execute([$student_id]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$student) {
        throw new Exception("Student not found.");
    }

    $student_id_int = $student['id']; // Get the INT id for duty_logs

    // Fetch duty logs with teacher info using the INT student_id
    $query = "SELECT dl.*, t.name as teacher_name 
              FROM duty_logs dl 
              LEFT JOIN teachers t ON t.id = dl.teacher_id 
              WHERE dl.student_id = ? AND dl.status IN ('Approved', 'Rejected')";
    $params = [$student_id_int];

    if ($status_filter !== 'all' && in_array($status_filter, ['Approved', 'Rejected'])) {
        $query .= " AND dl.status = ?";
        $params[] = $status_filter;
    }

    $query .= " ORDER BY dl.duty_date DESC, dl.time_in DESC";
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $duty_logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Debug: Log the fetched data to a file
    file_put_contents('generate_pdf_debug.log', "Student ID (VARCHAR): $student_id\n", FILE_APPEND);
    file_put_contents('generate_pdf_debug.log', "Student ID (INT): $student_id_int\n", FILE_APPEND);
    file_put_contents('generate_pdf_debug.log', "Duty Logs:\n" . print_r($duty_logs, true) . "\n", FILE_APPEND);

    // Check if there are logs
    if (empty($duty_logs)) {
        throw new Exception("No duty logs found for this student.");
    }

    // Determine required duty hours based on scholarship type
    function getRequiredHours($scholarship_type) {
        switch ($scholarship_type) {
            case "HK 25":
                return 50;
            case "HK 50":
                return 90;
            case "HK 75":
                return 120;
            default:
                return 90; // Default
        }
    }

    // Create PDF
    $pdf = new TCPDF('L', 'mm', 'A4', true, 'UTF-8', false);
    $pdf->SetCreator('Admin Panel');
    $pdf->SetAuthor('Administrative System');
    $pdf->SetTitle("Student Duty Logs - {$student['name']}");
    $pdf->SetSubject('Duty Log Report');
    $pdf->setPrintHeader(false);
    $pdf->setPrintFooter(false);
    $pdf->AddPage();

    // Set fonts
    $pdf->SetFont('helvetica', 'B', 16);

    // Center title
    $pdf->Cell(0, 10, "STUDENT DUTY LOGS REPORT", 0, 1, 'C');
    $pdf->Ln(5);

    // Student details
    $pdf->SetFont('helvetica', '', 11);
    $html = '<table border="0" cellpadding="3">
                <tr>
                    <td width="20%"><strong>Student Name:</strong></td>
                    <td>' . htmlspecialchars($student['name']) . '</td>
                    <td width="20%"><strong>Student ID:</strong></td>
                    <td>' . htmlspecialchars($student['student_id']) . '</td>
                </tr>
                <tr>
                    <td><strong>Course:</strong></td>
                    <td>' . htmlspecialchars($student['course']) . '</td>
                    <td><strong>Department:</strong></td>
                    <td>' . htmlspecialchars($student['department']) . '</td>
                </tr>
                <tr>
                    <td><strong>Year Level:</strong></td>
                    <td>' . htmlspecialchars($student['year_level']) . '</td>
                    <td><strong>HK Status:</strong></td>
                    <td>' . htmlspecialchars($student['hk_duty_status']) . '</td>
                </tr>
            </table>';

    $pdf->writeHTML($html, true, false, true, false, '');
    $pdf->Ln(5);

    // Duty logs table
    $html = '<table border="1" cellpadding="5" cellspacing="0" style="width:100%;">
                <tr style="background-color:#f2f2f2;">
                    <th align="center"><strong>Date</strong></th>
                    <th align="center"><strong>Time In</strong></th>
                    <th align="center"><strong>Time Out</strong></th>
                    <th align="center"><strong>Hours</strong></th>
                    <th align="center"><strong>Status</strong></th>
                    <th align="center"><strong>Handled By</strong></th>
                </tr>';

    $total_hours = 0;
    $approved_logs = 0;
    $rejected_logs = 0;

    foreach ($duty_logs as $log) {
        // Format times
        if (!empty($log['time_in']) && $log['time_in'] !== '0000-00-00 00:00:00') {
            $time_in = date('h:i A', strtotime($log['time_in']));
        } elseif ($log['total_hours'] > 0) {
            $time_in = "09:00 AM";
        } else {
            $time_in = 'N/A';
        }

        if (!empty($log['time_out']) && $log['time_out'] !== '0000-00-00 00:00:00') {
            $time_out = date('h:i A', strtotime($log['time_out']));
        } elseif ($log['total_hours'] > 0) {
            $hours_worked = (float)$log['total_hours'];
            $time_in_assumed = strtotime($log['duty_date'] . " 09:00:00");
            $time_out_inferred = $time_in_assumed + ($hours_worked * 3600);
            $time_out = date('h:i A', $time_out_inferred);
        } else {
            $time_out = 'N/A';
        }

        // Calculate hours and minutes using total_hours
        if ($log['status'] === 'Rejected') {
            $hours_formatted = "0 hrs";
            $rejected_logs++;
        } else {
            $hours_worked = (float)$log['total_hours'];
            $total_seconds = $hours_worked * 3600;
            $hours = floor($total_seconds / 3600);
            $minutes = round(($total_seconds % 3600) / 60);

            if ($hours > 0) {
                $hours_formatted = $hours . " hr" . ($hours > 1 ? "s" : "") . ($minutes > 0 ? " $minutes min" : "");
            } else {
                $hours_formatted = $minutes > 0 ? "$minutes min" : "0 hrs";
            }

            if ($log['status'] === 'Approved') {
                $total_hours += $hours_worked;
                $approved_logs++;
            }
        }

        // Prepare handled by info
        $handled_by = htmlspecialchars($log['teacher_name'] ?? 'N/A');
        $html .= '<tr>
                    <td align="center">' . date('M d, Y', strtotime($log['duty_date'])) . '</td>
                    <td align="center">' . $time_in . '</td>
                    <td align="center">' . $time_out . '</td>
                    <td align="center">' . $hours_formatted . '</td>
                    <td align="center">' . htmlspecialchars($log['status']) . '</td>
                    <td align="center">' . $handled_by . '</td>
                  </tr>';
    }

    $html .= '</table>';

    // Convert total hours to hours and minutes format
    $total_hours_whole = floor($total_hours); // Whole hours
    $total_minutes = round(($total_hours - $total_hours_whole) * 60); // Convert decimal to minutes

    if ($total_hours_whole > 0) {
        $total_hours_formatted = $total_hours_whole . " hr" . ($total_hours_whole > 1 ? "s" : "") . ($total_minutes > 0 ? " $total_minutes min" : "");
    } else {
        $total_hours_formatted = $total_minutes > 0 ? "$total_minutes min" : "0 hrs";
    }

    // Update the HTML to use the new format
    $html .= '<p><strong>Total Approved Hours: </strong>' . $total_hours_formatted . '</p>';
    $required_hours = getRequiredHours($student['scholarship_type']);
    $html .= "<p><strong>Total Hours to be Rendered: </strong> $required_hours hours</p>";
    $html .= '<p><strong>Total Logs: </strong>' . count($duty_logs) . 
             ' (Approved: ' . $approved_logs . ', Rejected: ' . $rejected_logs . ')</p>';

    $pdf->writeHTML($html, true, false, true, false, '');

    // Add signature line
    $pdf->Ln(20);
    $pdf->SetFont('helvetica', '', 10);
    $pdf->Cell(0, 10, "Verified by: ____________________", 0, 1, 'R');
    $pdf->Cell(0, 10, 'Expert Teacher/Dean', 0, 1, 'R');

    // Output PDF
    $pdf->Output("Student_Duty_Logs_{$student['name']}.pdf", 'D');

} catch (Exception $e) {
    // Log the error and display a user-friendly message
    error_log("Duty Logs PDF Generation Error: " . $e->getMessage());
    die("Error generating report: " . $e->getMessage());
}
?>