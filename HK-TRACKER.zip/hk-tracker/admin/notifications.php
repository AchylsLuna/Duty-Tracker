<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit();
}

// Fetch pending duties
$stmt = $pdo->query("
    SELECT d.*, s.name AS student_name, s.student_id, 
           TIMESTAMPDIFF(MINUTE, d.time_in, d.time_out) / 60 AS hours_worked,
           d.read_status
    FROM duty_logs d
    JOIN students s ON d.student_id = s.student_id
    WHERE d.status = 'Pending'
    ORDER BY d.duty_date DESC
");
$pending_duties = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Notifications</title>
    <link rel="stylesheet" href="../assets/notifications.css">
    <link rel="icon" href="../assets/image/icontitle.png" />
    <script src="../assets/dashboard.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="../assets/search_filter.js"></script>
    <script src="../assets/notifications.js"></script>
</head>

<body>
    <div class="dashboard-container">

        <?php include '../includes/sidebar.php'?>

        <main class="main-content">
            <div class="page-title">Notifications </div>

            <header class="header-container">
                <div class="pending-page">
                    <div class="header-left">
                        <h2><i class="fa-solid fa-hourglass-half"></i>Notification</h2>
                    </div>
                </div>
            </header>

            <section class="notifications-container">
                <div class="notifications-header">
                    <h2>NOTIFICATIONS <i class="fa-solid fa-paper-plane"></i></h2>
                    <div class="actions">
                        <!-- <button class="mark-all-read">Mark All as Read</button> -->
                        <!-- <button class="clear-all">Clear All</button> -->
                    </div>
                </div>

                <div class="notifications-list">
                    <ul>
                        <?php foreach ($pending_duties as $duty) : ?>
                        <li class="notification-item <?php echo $duty['read_status'] ? 'read' : 'pending'; ?>"
                            data-duty-id="<?php echo $duty['id']; ?>">

                            <!-- Red Dot for Unread Notifications -->
                            <?php if (!$duty['read_status']) : ?>
                            <span class="red-dot"></span>
                            <?php endif; ?>

                            <div class="notification-icon">
                                <i class="fa-solid fa-hourglass-half"></i>
                            </div>
                            <div class="notification-content">
                                <div class="notification-header">
                                    <div class="notification-title">Pending Duty:
                                        <?php echo htmlspecialchars($duty['student_name']); ?>
                                    </div>
                                    <div class="notification-time"><i class="fa-regular fa-clock"></i>
                                        <?php echo htmlspecialchars($duty['duty_date']); ?>
                                        <div class="notification-actions">
                                            <?php if (!$duty['read_status']) : ?>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <!-- Three Dots Menu (⋮) -->
                                    <div class="notification-options">
                                        <i class="fa-solid fa-ellipsis-vertical menu-icon"></i>
                                        <div class="options-dropdown">
                                            <button class="mark-unread">Mark as Unread</button>
                                            <button class="delete-notification">Delete</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="notification-message">
                                    Student ID: <?php echo htmlspecialchars($duty['student_id']); ?><br>
                                    Time In: <?php echo date("h:i A", strtotime($duty['time_in'])); ?><br>
                                    Time Out:
                                    <?php echo $duty['time_out'] ? date("h:i A", strtotime($duty['time_out'])) : 'N/A'; ?><br>
                                    Hours Worked:
                                    <?php echo ($duty['time_out']) ? number_format($duty['hours_worked'], 2) . ' hrs' : 'N/A'; ?>
                                </div>
                                <div class="notification-footer">
                                    <a href="approve_duty.php?duty_id=<?php echo $duty['id']; ?>" class="view-logs-btn"
                                        data-duty-id="<?php echo $duty['id']; ?>">

                                        <button><i class="fas fa-file-alt"></i> View Duty</button>
                                    </a>
                                    <span
                                        class="statuspending"><?php echo $duty['read_status'] ? 'Pending' : 'Pending'; ?></span>
                                </div>
                            </div>
                        </li>
                        <?php endforeach; ?>

                        <?php if (count($pending_duties) == 0) : ?>
                        <li class="notification-item">
                            <div class="notification-content">
                                <div class="notification-message">No pending duties found.</div>
                            </div>
                        </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </section>
        </main>
    </div>

</body>

</html>