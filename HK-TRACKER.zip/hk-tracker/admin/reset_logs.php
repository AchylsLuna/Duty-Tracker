<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json'); // Ensure JSON response

if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized access.']);
    exit();
}

if (!isset($_POST['student_id']) || empty($_POST['student_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request.']);
    exit();
}

$student_id = $_POST['student_id'];

try {
    $pdo->beginTransaction();

    // Check if student exists
    $checkStudent = $pdo->prepare("SELECT student_id FROM students WHERE student_id = ?");
    $checkStudent->execute([$student_id]);
    if (!$checkStudent->fetch()) {
        echo json_encode(['status' => 'error', 'message' => 'Student not found.']);
        exit();
    }

    // Delete logs
    $deleteLogs = $pdo->prepare("DELETE FROM duty_logs WHERE student_id = ?");
    $deleteLogs->execute([$student_id]);

    // Reset total hours
    $resetHours = $pdo->prepare("UPDATE students SET total_hours = 0 WHERE student_id = ?");
    $resetHours->execute([$student_id]);

    $pdo->commit();

    echo json_encode(['status' => 'success', 'message' => 'Duty logs successfully reset.']);
} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(['status' => 'error', 'message' => 'Error resetting logs: ' . $e->getMessage()]);
}

?>