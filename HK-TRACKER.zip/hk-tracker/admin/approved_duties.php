<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit();
}

// Initialize error and success messages from session
$error = isset($_SESSION['error']) ? $_SESSION['error'] : "";
$success = isset($_SESSION['success']) ? $_SESSION['success'] : "";
// Clear session messages after displaying
unset($_SESSION['error']);
unset($_SESSION['success']);

// Handle bulk actions (Resubmit, Delete All)
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['bulk_action'])) {
    $action = $_POST['bulk_action'];
    $selected_logs = isset($_POST['selected_logs']) ? json_decode($_POST['selected_logs'], true) : [];

    if (empty($selected_logs)) {
        $_SESSION['error'] = "No logs selected.";
    } else {
        $admin_id = $_SESSION['admin_id'];
        $pdo->beginTransaction();

        try {
            if ($action == 'resubmit') {
                $stmt = $pdo->prepare("
                    UPDATE duty_logs 
                    SET status = 'Pending', 
                        admin_id = NULL, 
                        approved_at = NULL
                    WHERE id = ? AND status = 'Approved'
                ");
                $affected_rows = 0;
                foreach ($selected_logs as $log_id) {
                    $stmt->execute([$log_id]);
                    $affected_rows += $stmt->rowCount(); // Count affected rows
                }
                if ($affected_rows === 0) {
                    throw new Exception("No logs were updated. Check if the selected logs are still Approved.");
                }
            } elseif ($action == 'delete') {
                $stmt = $pdo->prepare("DELETE FROM duty_logs WHERE id = ? AND status = 'Approved'");
                $affected_rows = 0;
                foreach ($selected_logs as $log_id) {
                    $stmt->execute([$log_id]);
                    $affected_rows += $stmt->rowCount();
                }
                if ($affected_rows === 0) {
                    throw new Exception("No logs were deleted. Check if the selected logs are still Approved.");
                }
            }

            $pdo->commit();
            $_SESSION['success'] = "Bulk action completed successfully. Affected rows: $affected_rows";
            header("Location: approved_duties.php");
            exit();
        } catch (Exception $e) {
            $pdo->rollBack();
            $_SESSION['error'] = "Error performing bulk action: " . $e->getMessage();
            header("Location: approved_duties.php");
            exit();
        }
    }
}

// Fetch approved duty logs (Ensuring duty_date is populated)
$stmt = $pdo->prepare("
    SELECT d.id, d.student_id, d.time_in, d.time_out, d.total_hours, d.status, d.approved_at,
           s.student_id AS student_number, s.name, s.course, s.department,
           COALESCE(d.duty_date, DATE(d.time_in)) AS duty_date
    FROM duty_logs d
    LEFT JOIN students s ON d.student_id = s.id
    WHERE d.status = 'Approved'
    ORDER BY d.approved_at DESC
");
$stmt->execute();
$approvedDuties = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Approved Duty Logs</title>
    <link rel="stylesheet" href="../assets/admin.css">
    <link rel="icon" href="../assets/image/icontitle.png" />
    <script src="../assets/dashboard.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="../assets/search_filter.js"></script>
    <script src="../assets/delete_logs.js"></script>
    <script src="../assets/resubmit_logs.js"></script>
</head>

<body>
    <div class="dashboard-container">

        <?php include '../includes/sidebar.php'; ?>

        <!-- Main Content -->
        <main class="main-content">
            <header class="header-container">
                <div class="approved-page">
                    <div class="header-left">
                        <h2><i class="fas fa-check-square"></i> Approved Duty Logs</h2>
                    </div>
                </div>

                <div class="header-right">
                    <div class="search-sort-container">
                        <div class="search-container">
                            <i class="fas fa-search"></i>
                            <input type="text" id="searchInput" placeholder="Search...">
                        </div>

                        <div class="dropdown">
                            <img src="../assets/image/sort-icon.jpg" alt="Sort" onclick="toggleDropdown()">
                            <div class="dropdown-content" id="dropdown">
                                <select id="sortSelect">
                                    <option value="" disabled selected>--Filter--</option>
                                    <option value="id">ID</option>
                                    <option value="student_id">Student ID</option>
                                    <option value="name">Name</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <section class="table-container">
                <div class="table-actions">
                    <button class="resubmit-btn" id="resubmitSelected">
                        <i class="fa fa-refresh"></i> Resubmit
                    </button>
                    <button class="delete-btn" id="deleteSelected">
                        <i class="fa fa-trash"></i> Delete All
                    </button>
                </div>
                <div class="table-content">
                    <table id="studentsTable">
                        <thead>
                            <tr>
                                <th><input type="checkbox" id="selectAll"></th>
                                <th class="sortable" data-column="student_id">Student ID</th>
                                <th class="sortable" data-column="name">Name</th>
                                <th class="sortable" data-column="department">Department</th>
                                <th class="sortable" data-column="duty_date">Duty Date</th>
                                <th class="sortable" data-column="time_in">Time In</th>
                                <th class="sortable" data-column="time_out">Time Out</th>
                                <th class="sortable" data-column="hours_worked">Hours Worked</th>
                                <th class="sortable" data-column="status">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($approvedDuties)): ?>
                            <tr>
                                <td colspan="9">No approved duty logs found.</td>
                            </tr>
                            <?php else: ?>
                            <?php foreach ($approvedDuties as $log): ?>
                            <tr>
                                <td><input type="checkbox" class="selectItem"
                                        value="<?php echo htmlspecialchars($log['id']); ?>"></td>
                                <td data-label="Student ID"><?php echo htmlspecialchars($log['student_number'] ?: $log['student_id']); ?></td>
                                <td data-label="Name"><?php echo htmlspecialchars($log['name'] ?: 'Unknown Student'); ?></td>
                                <td data-label="Department"><?php echo htmlspecialchars($log['department'] ?: 'N/A'); ?></td>
                                <td data-label="Duty Date"><?php echo htmlspecialchars($log['duty_date'] ?: 'N/A'); ?></td>
                                <td data-label="Time In"><?php echo date('h:i A', strtotime($log['time_in'])); ?></td>
                                <td data-label="Time Out"><?php echo date('h:i A', strtotime($log['time_out'])); ?></td>
                                <td data-label="Hours Worked">
                                    <?php 
                                    if ($log['total_hours'] > 0) {
                                        $hours = floor($log['total_hours']);
                                        $minutes = round(($log['total_hours'] - $hours) * 60);
                                        if ($hours > 0) {
                                            echo "{$hours} hr" . ($hours > 1 ? "s" : "");
                                            if ($minutes > 0) {
                                                echo " {$minutes} min";
                                            }
                                        } else {
                                            echo "{$minutes} min";
                                        }
                                    } else {
                                        echo "0 min";
                                    }
                                    ?>
                                </td>
                                <td data-label="Status" class="status-approved">
                                    <?php 
                                    if ($log['status'] == 'Approved') {
                                        echo '<i class="fa-solid fa-check-circle"></i> '; // Add the approved icon
                                    } 
                                    echo htmlspecialchars($log['status']); 
                                    ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </main>
    </div>

</body>
<script>

</script>

</html>