<?php
session_start();
require_once '../config/database.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

// Validate duty ID
if (!isset($_GET['duty_id']) || !is_numeric($_GET['duty_id'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid duty ID']);
    exit();
}

$duty_id = $_GET['duty_id'];

try {
    // Prepare and execute update statement to mark as unread
    $stmt = $pdo->prepare("UPDATE duty_logs SET read_status = 0 WHERE id = ?");
    $result = $stmt->execute([$duty_id]);

    if ($result) {
        echo json_encode(['success' => true, 'message' => 'Notification marked as unread']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to mark notification as unread']);
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
exit();