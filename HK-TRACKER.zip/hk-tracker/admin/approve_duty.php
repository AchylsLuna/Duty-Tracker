<?php
session_start();
require_once '../config/database.php';
require_once 'hours_format.php'; 

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit();
}

$error = "";
$success = "";

// Fetch pending duty logs
$stmt = $pdo->prepare("
    SELECT dl.id, dl.student_id, dl.time_in, dl.time_out, dl.total_hours, dl.status, 
           s.name AS student_name, s.student_id AS student_number, s.department,
           DATE(dl.time_in) AS duty_date
    FROM duty_logs dl
    LEFT JOIN students s ON dl.student_id = s.id
    WHERE dl.status = 'Pending'
    ORDER BY dl.time_in DESC
");
$stmt->execute();
$pending_logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle approval/rejection (single log)
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['log_id'], $_POST['action'])) {
    $log_id = $_POST['log_id'];
    $action = $_POST['action'];
    $admin_id = $_SESSION['admin_id'];

    // Check if there are updated values from the modal
    $updated_date = isset($_POST['editdate']) ? $_POST['editdate'] : null;
    $updated_time_in = isset($_POST['timein']) ? $_POST['timein'] : null;
    $updated_time_out = isset($_POST['timeout']) ? $_POST['timeout'] : null;

    $pdo->beginTransaction();

    try {
        if ($action == 'Approved') {
            $stmt_log = $pdo->prepare("SELECT time_in, time_out, student_id, duty_date FROM duty_logs WHERE id = ?");
            $stmt_log->execute([$log_id]);
            $log_data = $stmt_log->fetch(PDO::FETCH_ASSOC);

            if ($log_data) {
                $duty_date = $updated_date ?: $log_data['duty_date'];
                $time_in = $updated_time_in ?: $log_data['time_in'];
                $time_out = $updated_time_out ?: $log_data['time_out'];

                $total_hours = 0.00;
                if ($time_in && $time_out) {
                    $start = new DateTime($time_in);
                    $end = new DateTime($time_out);
                    if ($end > $start) {
                        $interval = $start->diff($end);
                        $total_hours = $interval->h + ($interval->i / 60);
                        $total_hours = round($total_hours, 2);
                    }
                }

                $stmt_update = $pdo->prepare("
                    UPDATE duty_logs 
                    SET status = 'Approved', 
                        total_hours = ?, 
                        admin_id = ?, 
                        approved_at = NOW(),
                        duty_date = ?,
                        time_in = ?,
                        time_out = ?
                    WHERE id = ?
                ");
                $stmt_update->execute([$total_hours, $admin_id, $duty_date, $time_in, $time_out, $log_id]);

                $stmt_total_hours = $pdo->prepare("
                    SELECT IFNULL(SUM(total_hours), 0) 
                    FROM duty_logs 
                    WHERE student_id = ? AND status = 'Approved'
                ");
                $stmt_total_hours->execute([$log_data['student_id']]);
                $total_hours_rendered = $stmt_total_hours->fetchColumn();

                $stmt_student_update = $pdo->prepare("
                    UPDATE students 
                    SET total_hours = ? 
                    WHERE student_id = ?
                ");
                $stmt_student_update->execute([$total_hours_rendered, $log_data['student_id']]);

                $stmt_log_update = $pdo->prepare("
                    UPDATE duty_logs 
                    SET total_hours = ? 
                    WHERE id = ?
                ");
                $stmt_log_update->execute([$total_hours_rendered, $log_id]);
            }
        } else {
            $stmt_reject = $pdo->prepare("
                UPDATE duty_logs 
                SET status = 'Rejected', 
                    total_hours = NULL, 
                    total_hours = 0.00 
                WHERE id = ?
            ");
            $stmt_reject->execute([$log_id]);
        }

        $pdo->commit();
        $success = "Duty log successfully updated.";
        header("Location: approve_duty.php");
        exit();
    } catch (Exception $e) {
        $pdo->rollBack();
        $error = "Error updating duty log: " . $e->getMessage();
    }
}

// Handle bulk actions (Approve All, Delete All)
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['bulk_action'])) {
    $action = $_POST['bulk_action'];
    $selected_logs = isset($_POST['selected_logs']) ? json_decode($_POST['selected_logs'], true) : [];

    if (empty($selected_logs)) {
        $error = "No logs selected.";
    } else {
        $admin_id = $_SESSION['admin_id'];
        $pdo->beginTransaction();

        try {
            if ($action == 'approve') {
                foreach ($selected_logs as $log_id) {
                    $stmt_log = $pdo->prepare("SELECT time_in, time_out, student_id, duty_date FROM duty_logs WHERE id = ? AND status = 'Pending'");
                    $stmt_log->execute([$log_id]);
                    $log_data = $stmt_log->fetch(PDO::FETCH_ASSOC);

                    if ($log_data) {
                        $time_in = $log_data['time_in'];
                        $time_out = $log_data['time_out'];
                        $duty_date = $log_data['duty_date'];

                        $total_hours = 0.00;
                        if ($time_in && $time_out) {
                            $start = new DateTime($time_in);
                            $end = new DateTime($time_out);
                            if ($end > $start) {
                                $interval = $start->diff($end);
                                $total_hours = $interval->h + ($interval->i / 60);
                                $total_hours = round($total_hours, 2);
                            }
                        }

                        $stmt = $pdo->prepare("
                            UPDATE duty_logs 
                            SET status = 'Approved', 
                                total_hours = ?, 
                                admin_id = ?, 
                                approved_at = NOW(),
                                duty_date = ?,
                                time_in = ?,
                                time_out = ?
                            WHERE id = ? AND status = 'Pending'
                        ");
                        $stmt->execute([$total_hours, $admin_id, $duty_date, $time_in, $time_out, $log_id]);

                        $stmt_total_hours = $pdo->prepare("
                            SELECT IFNULL(SUM(total_hours), 0) 
                            FROM duty_logs 
                            WHERE student_id = ? AND status = 'Approved'
                        ");
                        $stmt_total_hours->execute([$log_data['student_id']]);
                        $total_hours_rendered = $stmt_total_hours->fetchColumn();

                        $stmt_student_update = $pdo->prepare("
                            UPDATE students 
                            SET total_hours = ? 
                            WHERE student_id = ?
                        ");
                        $stmt_student_update->execute([$total_hours_rendered, $log_data['student_id']]);
                    }
                }
                $success = "All selected duty logs approved successfully.";
            } elseif ($action == 'delete') {
                $stmt = $pdo->prepare("DELETE FROM duty_logs WHERE id = ? AND status = 'Pending'");
                foreach ($selected_logs as $log_id) {
                    $stmt->execute([$log_id]);
                }
                $success = "All selected duty logs deleted successfully.";
            }

            $pdo->commit();
            header("Location: approve_duty.php");
            exit();
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = "Error approving duty logs: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Approve Duty Logs</title>
    <link rel="icon" href="../assets/image/icontitle.png" />
    <link rel="stylesheet" href="../assets/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <script src="../assets/search_filter.js"></script>
    <script src="../assets/delete_logs.js"></script>
    <script src="../assets/approve_logs.js"></script>
</head>

<body>
    <div class="dashboard-container">
        <?php include '../includes/sidebar.php'?>

        <main class="main-content">
            <header class="header-container">
                <div class="header-left">
                    <h2> <i class="fa-solid fa-hourglass-half" style="color: #f39c12"></i> Pending Duty Logs</h2>
                </div>

                <div class="header-right">
                    <div class="search-sort-container">
                        <div class="search-container">
                            <i class="fas fa-search"></i>
                            <input type="text" id="searchInput" placeholder="Search...">
                        </div>

                        <div class="dropdown">
                            <img src="../assets/image/sort-icon.jpg" alt="Sort" onclick="toggleDropdown()">
                            <div class="dropdown-content" id="dropdown">
                                <select id="sortSelect">
                                    <option value="" disabled selected>--Filter--</option>
                                    <option value="id">ID</option>
                                    <option value="student_id">Student ID</option>
                                    <option value="name">Name</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            <?php if (!empty($error)): ?>
            <p class="error"><?php echo $error; ?></p>
            <?php elseif (!empty($success)): ?>
            <p class="success"><?php echo $success; ?></p>
            <?php endif; ?>
            <section class="table-container">
                <div class="table-actions">
                    <button class="delete-btn" id="deleteSelected">
                        <i class="fa fa-trash"></i> Delete All
                    </button>

                    <button class="approve-selected-btn" id="approveSelected">
                        <i class="fa fa-thumbs-up"></i> Approve All
                    </button>
                </div>

                <div class="table-content">
                    <table id="studentsTable">
                        <thead>
                            <tr>
                                <th><input type="checkbox" id="selectAll"></th>
                                <th>Student Name</th>
                                <th>Student ID</th>
                                <th>Duty Date</th>
                                <th>Time In</th>
                                <th>Time Out</th>
                                <th>Hours Worked</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($pending_logs)): ?>
                            <tr>
                                <td colspan="9">No pending duty logs.</td>
                            </tr>
                            <?php else: ?>
                            <?php foreach ($pending_logs as $log): ?>
                            <tr>
                                <td><input type="checkbox" class="selectItem"
                                        value="<?php echo htmlspecialchars($log['id']); ?>"></td>
                                <td><?php echo htmlspecialchars($log['student_name']); ?></td>
                                <td><?php echo htmlspecialchars($log['student_number']); ?></td>
                                <td><?php echo date('Y-m-d', strtotime($log['duty_date'])); ?></td>
                                <td><?php echo date('h:i A', strtotime($log['time_in'])); ?></td>
                                <td><?php echo $log['time_out'] ? date('h:i A', strtotime($log['time_out'])) : 'N/A'; ?></td>
                                <td>
                                    <?php 
                                    if ($log['status'] == 'Rejected') {
                                        echo "N/A";
                                    } else {
                                        formatDutyHours($log); // Assumes hours_format.php provides this function
                                    }
                                    ?>
                                </td>
                                <td class="<?php echo $log['status'] == 'Pending' ? 'status-pending' : ''; ?>">
                                    <?php 
                                    if ($log['status'] == 'Pending') {
                                        echo '<i class="fa-solid fa-clock"></i> ';
                                    } 
                                    echo htmlspecialchars($log['status']); 
                                    ?>
                                </td>
                                <td>
                                    <button type="button" onclick="openModal(<?php 
                                    echo htmlspecialchars(json_encode([
                                        'id' => $log['id'],
                                        'date' => date('Y-m-d', strtotime($log['duty_date'])),
                                        'timeIn' => date('H:i', strtotime($log['time_in'])),
                                        'timeOut' => $log['time_out'] ? date('H:i', strtotime($log['time_out'])) : '',
                                        'student' => $log['student_name'],
                                        'student_id' => $log['student_number']
                                    ])); 
                                    ?>)">
                                        <img src="../assets/image/threedots.svg" alt="actionbutton" class="three-dots">
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </main>
    </div>

    <!-- Modal -->
    <div class="form-modal" id="form_popup">
        <div class="form-content">
            <h3>Review Time Log</h3>
            <form id="timeForm" method="POST" action="">
                <input type="hidden" id="log_id" name="log_id">

                <label for="edit_date">Date</label>
                <input type="date" id="edit_date" name="editdate" required>

                <label for="edit_timein">Time in</label>
                <input type="time" id="edit_timein" name="timein" required>

                <label for="edit_timeout">Time out</label>
                <input type="time" id="edit_timeout" name="timeout" required>

                <div class="buttons">
                    <button type="button" onclick="closeModal()">Cancel</button>
                    <button type="submit" name="action" value="Rejected" class="reject-button">Reject</button>
                    <button type="submit" name="action" value="Approved" class="approve-button">Approve</button>
                </div>
            </form>
        </div>
    </div>

    <script>
    function openModal(logData) {
        document.getElementById('form_popup').style.display = 'flex';
        document.getElementById('log_id').value = logData.id;
        document.getElementById('edit_date').value = logData.date;
        document.getElementById('edit_timein').value = logData.timeIn;
        document.getElementById('edit_timeout').value = logData.timeOut;
        console.log('Student: ' + logData.student + ' (' + logData.student_id + ')');
    }

    function closeModal() {
        document.getElementById('form_popup').style.display = 'none';
    }

    window.onclick = function(event) {
        var modal = document.getElementById('form_popup');
        if (event.target == modal) {
            closeModal();
        }
    }
    </script>

</body>

</html>