<?php
// Start output buffering to catch any unintended output
ob_start();

require_once '../config/database.php';

// Set headers immediately
header("Content-Type: application/json; charset=UTF-8");

// Initialize response
$response = ['success' => false, 'message' => ''];

try {
    $headers = getallheaders();
    $authHeader = $headers['Authorization'] ?? '';
    $sessionToken = str_replace('Bearer ', '', trim($authHeader));

    if (empty($sessionToken)) {
        throw new Exception("Missing authorization token", 401);
    }

    if (!$pdo) {
        throw new Exception("Database connection failed", 500);
    }

    // Get student ID from session token
    $stmt = $pdo->prepare("SELECT id, name FROM students WHERE session_token = ?");
    $stmt->execute([$sessionToken]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$student) {
        throw new Exception("Invalid session token", 401);
    }

    $data = json_decode(file_get_contents('php://input'), true);

    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception("Invalid JSON format: " . json_last_error_msg(), 400);
    }

    $requiredFields = ['duty_date', 'time_in', 'time_out'];
    foreach ($requiredFields as $field) {
        if (empty($data[$field])) {
            throw new Exception("Missing required field: $field", 400);
        }
    }

    $dutyDate = filter_var(trim($data['duty_date']), FILTER_SANITIZE_STRING);
    $timeIn = date("Y-m-d H:i:s", strtotime(filter_var(trim($data['time_in']), FILTER_SANITIZE_STRING)));
    $timeOut = date("Y-m-d H:i:s", strtotime(filter_var(trim($data['time_out']), FILTER_SANITIZE_STRING)));

    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $dutyDate)) {
        throw new Exception("Invalid date format. Use YYYY-MM-DD", 400);
    }

    // Calculate hours worked for this entry
    $timeInObj = new DateTime($timeIn);
    $timeOutObj = new DateTime($timeOut);
    $interval = $timeInObj->diff($timeOutObj);
    $hoursWorkedEntry = $interval->h + ($interval->i / 60);

    // Start transaction
    $pdo->beginTransaction();

    // Insert new duty log
    $stmt = $pdo->prepare("
        INSERT INTO duty_logs (student_id, duty_date, time_in, time_out, total_hours, status)
        VALUES (?, ?, ?, ?, ?, 'Pending')
    ");
    $success = $stmt->execute([$student['id'], $dutyDate, $timeIn, $timeOut, $hoursWorkedEntry]);

    if (!$success) {
        throw new Exception("Failed to submit duty log", 500);
    }

    // Insert notification for admin
    $message = "New duty log submitted by {$student['name']} ({$student['id']}) on $dutyDate from $timeIn to $timeOut";
    $stmt = $pdo->prepare("
        INSERT INTO notifications (user_id, role, message, is_read)
        VALUES (?, 'Admin', ?, FALSE)
    ");
    $stmt->execute([$student['id'], $message]);

    // Commit transaction
    $pdo->commit();

    // Calculate total hours worked on the current day
    $stmt = $pdo->prepare("
        SELECT SUM(total_hours) AS hours_worked 
        FROM duty_logs 
        WHERE student_id = ? AND duty_date = ?
    ");
    $stmt->execute([$student['id'], $dutyDate]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $hoursWorked = $result['hours_worked'] ?? 0;

    // Calculate cumulative total hours across all logs
    $stmt = $pdo->prepare("
        SELECT SUM(total_hours) AS total_hours 
        FROM duty_logs 
        WHERE student_id = ?
    ");
    $stmt->execute([$student['id']]);
    $totalHours = $stmt->fetch(PDO::FETCH_ASSOC)['total_hours'] ?? 0;

    // Success response
    $response['success'] = true;
    $response['message'] = "Duty log submitted successfully";
    $response['hours_worked'] = $hoursWorked;
    $response['total_hours'] = $totalHours;

    http_response_code(200);

} catch (Exception $e) {
    if ($pdo && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    $response['message'] = $e->getMessage();
    http_response_code($e->getCode() ?: 500);
}

// Clear any buffered output (e.g., errors or whitespace) before sending JSON
ob_end_clean();

// Output JSON response
echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
exit();
?><?php
header('Content-Type: application/json');
require_once '../config/database.php';

// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Get the Authorization header
$headers = apache_request_headers();
$authHeader = isset($headers['Authorization']) ? $headers['Authorization'] : '';
$session_token = str_replace('Bearer ', '', $authHeader);

if (empty($session_token)) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'No session token provided']);
    exit;
}

// Verify session token and get student_id
try {
    $stmt = $pdo->prepare("SELECT id FROM students WHERE session_token = ?");
    $stmt->execute([$session_token]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$student) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Invalid session token']);
        exit;
    }
    $student_id = $student['id'];
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    exit;
}

// Handle duty log submission
if ($_SERVER["REQUEST_METHOD"] != "POST") {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);
$time_in = isset($data['time_in']) ? trim($data['time_in']) : null;
$time_out = isset($data['time_out']) ? trim($data['time_out']) : null;

// Validate time_in
if (!$time_in || $time_in === '00:00:00') {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Time in is required and cannot be 00:00:00']);
    exit;
}

// Validate time_out (optional, but if provided, it shouldn't be 00:00:00)
if ($time_out === '00:00:00') {
    $time_out = null;
}

// Validate that time_out is after time_in if both are provided
if ($time_in && $time_out) {
    $start = new DateTime($time_in);
    $end = new DateTime($time_out);
    if ($end <= $start) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Time out must be after time in']);
        exit;
    }
}

try {
    $stmt = $pdo->prepare("
        INSERT INTO duty_logs (student_id, time_in, time_out, total_hours, status)
        VALUES (?, ?, ?, ?, 'Pending')
    ");
    $total_hours = null;
    if ($time_in && $time_out) {
        $start = new DateTime($time_in);
        $end = new DateTime($time_out);
        $interval = $start->diff($end);
        $total_hours = $interval->h + ($interval->i / 60);
        $total_hours = round($total_hours, 2);
    }
    $stmt->execute([$student_id, $time_in, $time_out, $total_hours]);
    echo json_encode(['success' => true, 'message' => 'Duty log submitted successfully']);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    exit;
}
?>