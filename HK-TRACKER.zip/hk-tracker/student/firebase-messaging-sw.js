importScripts('https://www.gstatic.com/firebasejs/10.9.0/firebase-app.js');
importScripts('https://www.gstatic.com/firebasejs/10.9.0/firebase-messaging.js');

firebase.initializeApp({
    apiKey: "AIzaSyDgv3xLekQzWOP4-Vg8oqerT5Pg9xYcVpQ",
    authDomain: "mobile-web-d276b.firebaseapp.com",
    projectId: "mobile-web-d276b",
    storageBucket: "mobile-web-d276b.firebasestorage.app",
    messagingSenderId: "942737446738",
    appId: "1:942737446738:web:173f2be93945148b658c8b",
    measurementId: "G-69NNVRTFF2"
});

const messaging = firebase.messaging();