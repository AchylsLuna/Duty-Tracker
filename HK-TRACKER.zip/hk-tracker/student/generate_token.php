<?php
require_once '../config/database.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $fcm_token = $input['fcm_token'] ?? null;
    $student_id = $input['student_id'] ?? null;

    if (!$fcm_token || !$student_id) {
        http_response_code(400);
        echo json_encode(['error' => 'Missing FCM token or student_id']);
        exit;
    }

    try {
        $stmt = $pdo->prepare("
            UPDATE students 
            SET fcm_token = ? 
            WHERE student_id = ?
        ");
        $stmt->execute([$fcm_token, $student_id]);

        if ($stmt->rowCount() === 0) {
            http_response_code(404);
            echo json_encode(['error' => 'Student ID not found']);
        } else {
            http_response_code(200);
            echo json_encode(['message' => 'Token saved successfully']);
        }
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Failed to save token: ' . $e->getMessage()]);
    }
} else {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
}
?>