<?php
header('Content-Type: application/json');
require_once '../config/database.php';

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$headers = apache_request_headers();
$authHeader = isset($headers['Authorization']) ? $headers['Authorization'] : '';
$session_token = str_replace('Bearer ', '', $authHeader);

if (empty($session_token)) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'No session token provided']);
    exit;
}

try {
    $stmt = $pdo->prepare("SELECT id FROM students WHERE session_token = ?");
    $stmt->execute([$session_token]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$student) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Invalid session token']);
        exit;
    }
    $student_id = $student['id'];
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    exit;
}

try {
    $stmt = $pdo->prepare("
        SELECT 
            id,
            student_id,
            time_in,
            time_out,
            total_hours,
            DATE(time_in) as duty_date,
            status
        FROM duty_logs 
        WHERE student_id = ?
        ORDER BY time_in DESC
    ");
    $stmt->execute([$student_id]);
    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $formatted_logs = array_map(function($log) {
        return [
            'id' => (int)$log['id'],
            'student_id' => (int)$log['student_id'],
            'time_in' => $log['time_in'] ? date('h:i A', strtotime($log['time_in'])) : null,
            'time_out' => $log['time_out'] ? date('h:i A', strtotime($log['time_out'])) : null,
            'total_hours' => (float)$log['total_hours'],
            'duty_date' => $log['duty_date'],
            'status' => $log['status']
        ];
    }, $logs);

    echo json_encode([
        'success' => true,
        'logs' => $formatted_logs
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    exit;
}
?>