document.addEventListener("DOMContentLoaded", function() {
    // Modal Elements
    const addModal = document.getElementById("userModal");
    const openModalBtn = document.getElementById("openModalBtn");
    const closeModalBtn = document.getElementById("adminClose_button");
    const cancelBtn = document.getElementById("cancelBtn");
    // Delete modal elements
    const deleteModal = document.getElementById("deleteModal");
    const closeModal = document.getElementById("admin_close");
    const cancelDeleteBtn = document.getElementById("cancelDeleteBtn");
    const confirmDeleteBtn = document.getElementById("confirmDeleteBtn");
    const deleteUserButtons = document.querySelectorAll(".delete-user");
    // Edit modal elements
    const editModal = document.getElementById("editModal");
    const saveBtn = document.getElementById("saveBtn");
    const editForm = document.getElementById("editForm");
    const editCloseBtn = document.querySelector("#editModal .admin-close");
    const editCancelBtn = document.getElementById("cancelEditBtn");
    const editUserButtons = document.querySelectorAll(".edit-user");

    // Form Elements
    const addForm = document.getElementById("addForm");
    const submitBtn = document.getElementById("submitBtn");
    const passwordInput = document.getElementById("password");
    const confirmPasswordInput = document.getElementById("confirmPassword");
    const passwordToggles = document.querySelectorAll(".password-toggle");
    const passwordHints = document.querySelectorAll(".password-hints li");
    const strengthMeter = document.querySelector(".strength-meter");
    const strengthText = document.querySelector(".strength-text span");
    const passwordMatch = document.querySelector(".password-match");

    // Modal Functions
    function openAddModal() {
        addModal.classList.add("active");
        document.body.style.overflow = "hidden";
    }

    function closeAddModal() {
        addModal.classList.remove("active");
        document.body.style.overflow = "";
        if (addForm) addForm.reset();
        resetPasswordValidation();
    }

    function openDeleteModal() {
        deleteModal.classList.add("active");
        document.body.style.overflow = "hidden";
    }

    function closeDeleteModal() {
        deleteModal.classList.remove("active");
        document.body.style.overflow = "";
    }

    function openEditModal() {
        editModal.classList.add("active");
        document.body.style.overflow = "hidden";
    }

    function closeEditModal() {
        editModal.classList.remove("active");
        document.body.style.overflow = "";
        if (editForm) editForm.reset();
    }

    // Password Validation
    function checkPasswordStrength(password) {
        const strength = {
            length: password.length >= 8,
            uppercase: /[A-Z]/.test(password),
            number: /\d/.test(password),
            special: /[!@#$%^&*(),.?":{}|<>]/.test(password)
        };

        const strengthLevel = Object.values(strength).filter(Boolean).length;
        
        // Update hints
        passwordHints.forEach(hint => {
            const requirement = hint.getAttribute("data-requirement");
            hint.classList.toggle("valid", strength[requirement]);
        });

        // Update strength meter
        const strengthClasses = ["strength-weak", "strength-medium", "strength-strong", "strength-very-strong"];
        strengthMeter.className = "strength-meter " + strengthClasses[strengthLevel - 1];
        
        const strengthLabels = ["weak", "medium", "strong", "very strong"];
        strengthText.textContent = strengthLabels[strengthLevel - 1] || "";
        strengthText.style.color = getStrengthColor(strengthLevel);
        
        // Show strength meter if password not empty
        document.querySelector(".password-strength").style.display = password ? "block" : "none";
        
        return strengthLevel >= 3; // Consider medium or above as acceptable
    }

    function getStrengthColor(level) {
        const colors = [
            "var(--danger-color)",
            "var(--warning-color)",
            "var(--success-color)",
            "var(--primary-color)"
        ];
        return colors[level - 1] || "var(--danger-color)";
    }

    function checkPasswordMatch() {
        const password = passwordInput.value;
        const confirmPassword = confirmPasswordInput.value;
        const isValid = password && password === confirmPassword;
        
        passwordMatch.style.display = (password && confirmPassword) ? "flex" : "none";
        
        if (password && confirmPassword) {
            if (isValid) {
                passwordMatch.style.color = "var(--success-color)";
                passwordMatch.querySelector(".match-text").textContent = "Passwords match";
                passwordMatch.querySelector(".match-icon").className = "fas fa-check-circle match-icon";
            } else {
                passwordMatch.style.color = "var(--danger-color)";
                passwordMatch.querySelector(".match-text").textContent = "Passwords don't match";
                passwordMatch.querySelector(".match-icon").className = "fas fa-times-circle match-icon";
            }
        }
        
        return isValid;
    }

    function resetPasswordValidation() {
        passwordHints.forEach(hint => hint.classList.remove("valid"));
        document.querySelector(".password-strength").style.display = "none";
        passwordMatch.style.display = "none";
    }

    // Toggle Password Visibility
    passwordToggles.forEach(toggle => {
        toggle.addEventListener("click", function() {
            const input = this.previousElementSibling;
            const isPassword = input.type === "password";
            
            input.type = isPassword ? "text" : "password";
            this.innerHTML = isPassword ? '<i class="fas fa-eye-slash"></i>' : '<i class="fas fa-eye"></i>';
            this.setAttribute("aria-label", isPassword ? "Hide password" : "Show password");
        });
    });

    // Real-time Validation
    passwordInput.addEventListener("input", function() {
        checkPasswordStrength(this.value);
        checkPasswordMatch();
    });

    confirmPasswordInput.addEventListener("input", checkPasswordMatch);

    /* Form Submission
    if (addForm && submitBtn) {
        addForm.addEventListener("submit", function(e) {
            e.preventDefault();
            
            // Validate password
            const isStrongEnough = checkPasswordStrength(passwordInput.value);
            const isMatching = checkPasswordMatch();
            
            if (!isStrongEnough) {
                alert("Please create a stronger password (minimum: 8 characters with uppercase, number, and special character)");
                passwordInput.focus();
                return;
            }
            
            if (!isMatching) {
                alert("Passwords don't match!");
                confirmPasswordInput.focus();
                return;
            }
            
            // Show loading state
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<span class="btn-loading"></span> Creating User...';
            
            // Simulate form processing
            setTimeout(() => {
                alert("User added successfully!");
                closeAddModal();
                submitBtn.disabled = false;
                submitBtn.innerHTML = 'Add User';
            }, 1500);
        });
    }*/

    // Event Listeners for Add Modal
    if (openModalBtn) openModalBtn.addEventListener("click", openAddModal);
    if (closeModalBtn) closeModalBtn.addEventListener("click", closeAddModal);
    if (cancelBtn) cancelBtn.addEventListener("click", closeAddModal);
    
    if (addModal) {
        addModal.addEventListener("click", function(e) {
            if (e.target === addModal) closeAddModal();
        });
    }

    document.addEventListener("keydown", function(e) {
        if (e.key === "Escape" && addModal.classList.contains("active")) {
            closeAddModal();
        }
    });

    // Event Listeners for Delete Modal
    deleteUserButtons.forEach(button => {
        button.addEventListener("click", function() {
            openDeleteModal();
        });
    });

    if (closeModal) closeModal.addEventListener("click", closeDeleteModal);
    if (cancelDeleteBtn) cancelDeleteBtn.addEventListener("click", closeDeleteModal);
    
    if (deleteModal) {
        deleteModal.addEventListener("click", function(e) {
            if (e.target === deleteModal) closeDeleteModal();
        });
    }

    document.addEventListener("keydown", function(e) {
        if (e.key === "Escape" && deleteModal.classList.contains("active")) {
            closeDeleteModal();
        }
    });

    // Confirm Delete Action
    if (confirmDeleteBtn) {
        confirmDeleteBtn.addEventListener("click", function() {
            closeDeleteModal();
        });
    }

    // Event Listeners for Edit Modal
    editUserButtons.forEach(button => {
        button.addEventListener("click", function() {
            const userCard = this.closest(".user-card");
            const teacherId = userCard.getAttribute("data-teacher-id");
            const username = userCard.querySelector(".user-name").textContent;
            const email = userCard.querySelector(".info-value").textContent;
            const department = userCard.querySelector(".info-value").textContent;

            // Populate the edit form with user data
            editForm.elements["editTeacherId"].value = teacherId;
            editForm.elements["editUsername"].value = username;
            editForm.elements["editEmail"].value = email;
            editForm.elements["editDepartment"].value = department;

            openEditModal();
        });
    });

    if (editCloseBtn) editCloseBtn.addEventListener("click", closeEditModal);
    if (editCancelBtn) editCancelBtn.addEventListener("click", closeEditModal);
    
    if (editModal) {
        editModal.addEventListener("click", function(e) {
            if (e.target === editModal) closeEditModal();
        });
    }

    document.addEventListener("keydown", function(e) {
        if (e.key === "Escape" && editModal.classList.contains("active")) {
            closeEditModal();
        }
    });

    // Save Changes Action
    if (saveBtn) {
        saveBtn.addEventListener("click", function(e) {
            e.preventDefault();
            
            // Get the form data
            let formData = new FormData(editForm);
            
            // Submit the form data
            $.ajax({
                url: "edit_teacher.php",
                type: "POST",
                data: formData,
                contentType: false,
                processData: false,
                dataType: "json",
                success: function(response) {
                    if (response.success) {
                        alert(response.message || 'Teacher updated successfully');
                        window.location.reload();
                    } else {
                        alert("Error: " + (response.message || 'Update failed'));
                    }
                },
                error: function(xhr) {
                    alert("Error updating teacher: " + 
                        (xhr.responseJSON && xhr.responseJSON.message || xhr.statusText));
                },
                complete: function() {
                    closeEditModal();
                }
            });
        });
    }
});
document.addEventListener("DOMContentLoaded", function() {
    // Modal Elements
    const deleteModal = document.getElementById("deleteModal");
    const closeModal = document.getElementById("admin_close");
    const cancelDeleteBtn = document.getElementById("cancelDeleteBtn");
    const confirmDeleteBtn = document.getElementById("confirmDeleteBtn");
    const deleteUserButtons = document.querySelectorAll(".delete-user");

    let teacherIdToDelete = null;

    // Modal Functions
    function openDeleteModal() {
        deleteModal.classList.add("active");
        document.body.style.overflow = "hidden";
    }

    function closeDeleteModal() {
        deleteModal.classList.remove("active");
        document.body.style.overflow = "";
        teacherIdToDelete = null;
    }

    // Event Listeners for Delete Modal
    deleteUserButtons.forEach(button => {
        button.addEventListener("click", function() {
            teacherIdToDelete = this.getAttribute("data-teacher-id");
            openDeleteModal();
        });
    });

    if (closeModal) closeModal.addEventListener("click", closeDeleteModal);
    if (cancelDeleteBtn) cancelDeleteBtn.addEventListener("click", closeDeleteModal);
    
    if (deleteModal) {
        deleteModal.addEventListener("click", function(e) {
            if (e.target === deleteModal) closeDeleteModal();
        });
    }

    document.addEventListener("keydown", function(e) {
        if (e.key === "Escape" && deleteModal.classList.contains("active")) {
            closeDeleteModal();
        }
    });

    // Confirm Delete Action
    if (confirmDeleteBtn) {
        confirmDeleteBtn.addEventListener("click", function() {
            if (teacherIdToDelete) {
                fetch('delete_teacher.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: new URLSearchParams({ teacher_id: teacherIdToDelete })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert(data.message);
                        location.reload(); // Reload the page to reflect changes
                    } else {
                        alert(data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred while deleting the teacher.');
                })
                .finally(() => {
                    closeDeleteModal();
                });
            }
        });
    }
});
document.addEventListener("DOMContentLoaded", function() {
    // Modal Elements
    const editModal = document.getElementById("editModal");
    const saveBtn = document.getElementById("saveBtn");
    const editForm = document.getElementById("editForm");
    const editCloseBtn = document.querySelector("#editModal .admin-close");
    const editCancelBtn = document.getElementById("cancelEditBtn");
    const editUserButtons = document.querySelectorAll(".edit-user");

    // Function to open the edit modal
    function openEditModal() {
        editModal.classList.add("active");
        document.body.style.overflow = "hidden";
    }

    // Function to close the edit modal
    function closeEditModal() {
        editModal.classList.remove("active");
        document.body.style.overflow = "";
        if (editForm) editForm.reset();
    }

    // Event Listeners for Edit Modal
    editUserButtons.forEach(button => {
        button.addEventListener("click", function() {
            const teacherId = this.getAttribute("data-teacher-id");

            // Fetch teacher details via AJAX
            $.ajax({
                url: "edit_teacher.php",
                type: "POST",
                data: { teacher_id: teacherId },
                dataType: "json",
                success: function(response) {
                    if (response.success && response.teacher) {
                        // Populate form fields
                        $("#editTeacherId").val(response.teacher.id);
                        $("#editModal input[name='username']").val(response.teacher.name || '');
                        $("#editModal input[name='email']").val(response.teacher.email || '');
                        $("#editModal select[name='department']").val(response.teacher.department || '');

                        // Show the modal
                        openEditModal();
                    } else {
                        alert("Error: " + (response.message || 'Failed to load teacher data'));
                    }
                },
                error: function(xhr) {
                    alert("Error loading teacher: " + xhr.statusText);
                }
            });
        });
    });

    // Close Modal Handlers
    if (editCloseBtn) editCloseBtn.addEventListener("click", closeEditModal);
    if (editCancelBtn) editCancelBtn.addEventListener("click", closeEditModal);

    if (editModal) {
        editModal.addEventListener("click", function(e) {
            if (e.target === editModal) closeEditModal();
        });
    }

    document.addEventListener("keydown", function(e) {
        if (e.key === "Escape" && editModal.classList.contains("active")) {
            closeEditModal();
        }
    });

    // Save Changes Button Handler
    if (saveBtn) {
        saveBtn.addEventListener("click", function(e) {
            e.preventDefault();

            // Create FormData object from the form
            let formData = new FormData(editForm);
            

            // Submit the form data
            $.ajax({
                url: "edit_teacher.php",
                type: "POST",
                data: formData,
                contentType: false,
                processData: false,
                dataType: "json",
                success: function(response) {
                    if (response.success) {
                        window.location.reload();
                    } else {
                        alert("Error: " + (response.message || 'Update failed'));
                    }
                },
                error: function(xhr) {
                    alert("Error updating teacher: " + 
                        (xhr.responseJSON && xhr.responseJSON.message || xhr.statusText));
                }
            });
        });
    }
});
function viewStudents(button) {
    var teacherId = button.getAttribute("data-teacher-id");
    window.location.href = "viewteacher_handle.php?teacher_id=" + teacherId;
}