document.addEventListener('DOMContentLoaded', function () {
    // Function to handle marking notification as read
    function markNotificationRead(dutyId) {
        fetch(`mark_notification_read.php?duty_id=${dutyId}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const notificationItem = document.querySelector(`.notification-item[data-duty-id="${dutyId}"]`);
                if (notificationItem) {
                    // Remove red dot
                    const redDot = notificationItem.querySelector('.red-dot');
                    if (redDot) redDot.remove();
                    
                    // Update status and classes
                    notificationItem.classList.remove('pending');
                    notificationItem.classList.add('read');
                    
                    // Update status text
                    const statusElement = notificationItem.querySelector('.statuspending');
                    if (statusElement) statusElement.textContent = 'Read';
                }
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
    }

    // Function to handle marking notification as unread
    function markNotificationUnread(dutyId) {
        fetch(`mark_notification_unread.php?duty_id=${dutyId}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const notificationItem = document.querySelector(`.notification-item[data-duty-id="${dutyId}"]`);
                if (notificationItem) {
                    // Add red dot
                    if (!notificationItem.querySelector('.red-dot')) {
                        const redDot = document.createElement('span');
                        redDot.classList.add('red-dot');
                        notificationItem.insertBefore(redDot, notificationItem.firstChild);
                    }
                    
                    // Update status and classes
                    notificationItem.classList.remove('read');
                    notificationItem.classList.add('pending');
                    
                    // Update status text
                    const statusElement = notificationItem.querySelector('.statuspending');
                    if (statusElement) statusElement.textContent = 'Pending';
                }
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
    }

    // Event listener for View Duty link to mark as read
    document.querySelectorAll('.view-logs-btn').forEach(btn => {
        btn.addEventListener('click', function (e) {
            const dutyId = this.getAttribute('data-duty-id');
            markNotificationRead(dutyId);
        });
    });

    // Event listener for Mark as Unread button
    document.querySelectorAll('.mark-unread').forEach(btn => {
        btn.addEventListener('click', function (e) {
            e.preventDefault();
            const notificationItem = this.closest('.notification-item');
            const dutyId = notificationItem.getAttribute('data-duty-id');
            markNotificationUnread(dutyId);
        });
    });

    // Event listener for Teacher Notifications
    document.querySelectorAll('.teacher-notification').forEach(btn => {
        btn.addEventListener('click', function (e) {
            e.preventDefault();
            const dutyId = this.getAttribute('data-duty-id');
            markNotificationRead(dutyId);
        });
    });

    // Toggle dropdown menu when clicking on the menu icon
    document.querySelectorAll('.menu-icon').forEach(icon => {
        icon.addEventListener('click', function (event) {
            event.stopPropagation(); // Prevent immediate closing
            let dropdown = this.nextElementSibling;

            // Close other open dropdowns before opening this one
            document.querySelectorAll('.options-dropdown').forEach(menu => {
                if (menu !== dropdown) menu.classList.remove('show');
            });

            // Toggle the visibility of the current dropdown
            dropdown.classList.toggle('show');
        });
    });

    // Hide dropdown when clicking outside
    document.addEventListener('click', function (event) {
        document.querySelectorAll('.options-dropdown').forEach(menu => {
            if (!menu.contains(event.target) && !event.target.classList.contains('menu-icon')) {
                menu.classList.remove('show');
            }
        });
    });
});
