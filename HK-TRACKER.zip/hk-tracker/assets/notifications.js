document.addEventListener('DOMContentLoaded', function() { 
    // Function to handle marking notification as read
    function markNotificationRead(dutyId) {
        fetch(`mark_notification_read.php?duty_id=${dutyId}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const notificationItem = document.querySelector(`.notification-item[data-duty-id="${dutyId}"]`);
                if (notificationItem) {
                    const redDot = notificationItem.querySelector('.red-dot');
                    if (redDot) redDot.remove();

                    notificationItem.classList.remove('pending');
                    notificationItem.classList.add('read');

                    const statusElement = notificationItem.querySelector('.statuspending');
                    if (statusElement) statusElement.textContent = 'Read';
                }
            }
        })
        .catch(error => console.error('Error:', error));
    }

    // Function to handle marking notification as unread
    function markNotificationUnread(dutyId) {
        fetch(`mark_notification_unread.php?duty_id=${dutyId}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const notificationItem = document.querySelector(`.notification-item[data-duty-id="${dutyId}"]`);
                if (notificationItem) {
                    if (!notificationItem.querySelector('.red-dot')) {
                        const redDot = document.createElement('span');
                        redDot.classList.add('red-dot');
                        notificationItem.insertBefore(redDot, notificationItem.firstChild);
                    }

                    notificationItem.classList.remove('read');
                    notificationItem.classList.add('pending');

                    const statusElement = notificationItem.querySelector('.statuspending');
                    if (statusElement) statusElement.textContent = 'Pending';
                }
            }
        })
        .catch(error => console.error('Error:', error));
    }

    // Toggle dropdown menu when clicking on three dots
    document.querySelectorAll('.menu-icon').forEach(icon => {
        icon.addEventListener('click', function(event) {
            event.stopPropagation(); // Prevent immediate closing
            let dropdown = this.nextElementSibling;

            // Close other open dropdowns before opening this one
            document.querySelectorAll('.options-dropdown').forEach(menu => {
                if (menu !== dropdown) menu.classList.remove('show');
            });

            // Toggle the visibility of the current dropdown
            dropdown.classList.toggle('show');
        });
    });

    // Hide dropdown when clicking outside
    document.addEventListener('click', function(event) {
        document.querySelectorAll('.options-dropdown').forEach(menu => {
            if (!menu.contains(event.target) && !event.target.classList.contains('menu-icon')) {
                menu.classList.remove('show');
            }
        });
    });

    // Event listener for View Duty link to mark as read
    document.querySelectorAll('.view-logs-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const dutyId = this.getAttribute('data-duty-id');
            markNotificationRead(dutyId);
        });
    });

    // Event listener for Mark as Unread button
    document.querySelectorAll('.mark-unread').forEach(btn => {
        btn.addEventListener('click', function() {
            const dutyId = this.closest('.notification-item').getAttribute('data-duty-id');
            markNotificationUnread(dutyId);
        });
    });

    // Delete Notification functionality
    document.querySelectorAll('.delete-notification').forEach(btn => {
        btn.addEventListener('click', function() {
            const notificationItem = this.closest('.notification-item');
            const dutyId = notificationItem.getAttribute('data-duty-id');

            fetch(`delete_notification.php?duty_id=${dutyId}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    notificationItem.remove();
                }
            })
            .catch(error => console.error('Error:', error));
        });
    });
});
