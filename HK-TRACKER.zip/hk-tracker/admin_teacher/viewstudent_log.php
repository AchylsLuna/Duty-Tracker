<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['teacher_id'])) {
    header('Location: login.php');
    exit();
}

$teacher_id = $_SESSION['teacher_id'];

if (!isset($_GET['student_id'])) {
    echo "Student ID not provided.";
    exit();
}

$student_number = $_GET['student_id'];

// Fetch the student's ID (INT) using the student_id (VARCHAR)
$stmt = $pdo->prepare("SELECT id FROM students WHERE student_id = ?");
$stmt->execute([$student_number]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$student) {
    echo "Student not found.";
    exit();
}

$student_id = $student['id'];

// Fetch duty logs for the student
$stmt = $pdo->prepare("
    SELECT * FROM duty_logs 
    WHERE student_id = ? 
    ORDER BY duty_date DESC, time_in DESC
");
$stmt->execute([$student_id]);
$duty_logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate total hours using the total_hours column
$total_hours = 0;
foreach ($duty_logs as $log) {
    if ($log['status'] === 'Approved') {
        $total_hours += (float)$log['total_hours'];
    }
}

// Debug: Check the fetched data
$debug_student_id = $student_id;
$debug_duty_logs = $duty_logs;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Student Logs</title>
    <link rel="icon" href="../assets/image/icontitle.png" />
    <link rel="stylesheet" href="../assets/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="../assets/search_filter.js"></script>
    <style>
    .dropdown {
        position: relative;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        vertical-align: middle;
        display: inline-block;
    }

    .dropdown-content {
        display: none;
        position: absolute;
        background-color: white;
        box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.2);
        min-width: 140px;
        z-index: 1;
        right: 0;
        border-radius: 5px;
        padding: 5px 0;
    }

    .dropdown-content a {
        color: black;
        padding: 8px 12px;
        text-decoration: none;
        display: block;
        cursor: pointer;
    }

    .dropdown-content a:hover {
        background-color: #f1f1f1;
    }

    .dropdown:hover .dropdown-content {
        display: block;
    }
    </style>
</head>

<body>
    <div class="dashboard-container">
        <?php include '../includes/teacher_sidebar.php'; ?>
        <main class="main-content">
            <header class="header-container">
                <div class="header-left">
                    <h2>
                        <i class="fa-solid fa-arrow-left" onclick="window.location.href='teacher_students.php'"
                            style="cursor: pointer;"></i>
                        <i class="fa-regular fa-clock"></i>
                        Student View Logs
                    </h2>
                </div>
                <div class="header-right">
                    <div class="search-sort-container">
                        <div class="search-container">
                            <i class="fas fa-search"></i>
                            <input type="text" id="searchInput" placeholder="Search...">
                        </div>
                        <div class="dropdown">
                            <img src="../assets/image/sort-icon.jpg" alt="Sort" onclick="toggleDropdown()">
                            <div class="dropdown-content" id="dropdown">
                                <select id="sortSelect">
                                    <option value="" disabled selected>--Filter--</option>
                                    <option value="id">ID</option>
                                    <option value="student_id">Student ID</option>
                                    <option value="name">Name</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </header>



            <section class="table-container">
                <table id="studentsTable">
                    <thead>
                        <tr>
                            <th>Duty Date</th>
                            <th>Time In</th>
                            <th>Time Out</th>
                            <th>Hours Worked</th>
                            <th>Status
                                <div class="dropdown">
                                    <img src="../assets/image/drop-status.png" alt="Filter Status"
                                        style="width: 18px; height: 18px; cursor: pointer; margin-right: 5px;">
                                    <div class="dropdown-content">
                                        <a onclick="filterByStatus('All')">Show All</a>
                                        <a onclick="filterByStatus('Approved')">Approved</a>
                                        <a onclick="filterByStatus('Pending')">Pending</a>
                                        <a onclick="filterByStatus('Rejected')">Rejected</a>
                                    </div>
                                </div>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($duty_logs)): ?>
                        <?php foreach ($duty_logs as $log): ?>
                        <tr class="log-row" data-status="<?php echo $log['status']; ?>">
                            <td>
                                <?php 
                                // Ensure duty_date is not null and not '0000-00-00'
                                if (!empty($log['duty_date']) && $log['duty_date'] !== '0000-00-00') {
                                    echo date('Y-m-d', strtotime($log['duty_date']));
                                } else {
                                    echo 'N/A';
                                }
                                ?>
                            </td>
                            <td>
                                <?php 
                                // Check if time_in is valid
                                if (!empty($log['time_in']) && $log['time_in'] !== '0000-00-00 00:00:00') {
                                    echo date('h:i A', strtotime($log['time_in']));
                                } elseif ($log['total_hours'] > 0) {
                                    // Infer time_in as 9:00 AM if total_hours is available
                                    echo "09:00 AM";
                                } else {
                                    echo 'N/A';
                                }
                                ?>
                            </td>
                            <td>
                                <?php 
                                // Check if time_out is valid
                                if (!empty($log['time_out']) && $log['time_out'] !== '0000-00-00 00:00:00') {
                                    echo date('h:i A', strtotime($log['time_out']));
                                } elseif ($log['total_hours'] > 0) {
                                    // Infer time_out based on total_hours (assuming time_in is 9:00 AM)
                                    $hours_worked = (float)$log['total_hours'];
                                    $time_in_assumed = strtotime($log['duty_date'] . " 09:00:00");
                                    $time_out_inferred = $time_in_assumed + ($hours_worked * 3600);
                                    echo date('h:i A', $time_out_inferred);
                                } else {
                                    echo 'N/A';
                                }
                                ?>
                            </td>
                            <td>
                                <?php
                                // Use total_hours from the database
                                $hours_worked = (float)$log['total_hours'];
                                if ($log['status'] === 'Rejected') {
                                    echo "0 hrs";
                                } else {
                                    $total_seconds = $hours_worked * 3600;
                                    $hours = floor($total_seconds / 3600);
                                    $minutes = round(($total_seconds % 3600) / 60);

                                    if ($hours > 0) {
                                        echo $hours . " hr" . ($hours > 1 ? "s" : "") . ($minutes > 0 ? " $minutes min" : "");
                                    } else {
                                        echo $minutes > 0 ? "$minutes min" : "0 hrs";
                                    }
                                }
                                ?>
                            </td>
                            <td class="
                                <?php 
                                echo ($log['status'] == 'Pending') ? 'status-pending' : 
                                     (($log['status'] == 'Approved') ? 'status-approved' : 
                                     (($log['status'] == 'Rejected') ? 'status-rejected' : '')); 
                                ?>
                            ">
                                <?php 
                                if ($log['status'] == 'Pending') {
                                    echo '<i class="fa-solid fa-clock"></i> Pending';
                                } elseif ($log['status'] == 'Approved') {
                                    echo '<i class="fa-solid fa-check-circle"></i> Approved';
                                } elseif ($log['status'] == 'Rejected') {
                                    echo '<i class="fa-solid fa-times-circle"></i> Rejected';
                                } else {
                                    echo htmlspecialchars($log['status']);
                                }
                                ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php else: ?>
                        <tr>
                            <td colspan="5">No duty logs found.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </section>
            <p class="total-hours-container-text"><strong>Total Hours Worked:</strong>
                <?php 
                $total_seconds = $total_hours * 3600;
                $hours = floor($total_seconds / 3600);
                $minutes = round(($total_seconds % 3600) / 60);

                if ($hours > 0) {
                    echo $hours . " hr" . ($hours > 1 ? "s" : "") . ($minutes > 0 ? " $minutes min" : "");
                } else {
                    echo $minutes > 0 ? "$minutes min" : "0 hrs";
                }
                ?>
            </p>
        </main>
    </div>

    <script>
    function filterByStatus(status) {
        let rows = document.querySelectorAll(".log-row");

        rows.forEach(row => {
            let rowStatus = row.getAttribute("data-status");

            if (status === "All" || rowStatus === status) {
                row.style.display = "";
            } else {
                row.style.display = "none";
            }
        });
    }
    </script>
</body>

</html>